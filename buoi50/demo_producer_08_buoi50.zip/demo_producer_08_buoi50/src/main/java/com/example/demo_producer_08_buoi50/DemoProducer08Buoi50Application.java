package com.example.demo_producer_08_buoi50;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProducer08Buoi50Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoProducer08Buoi50Application.class, args);
	}

}
