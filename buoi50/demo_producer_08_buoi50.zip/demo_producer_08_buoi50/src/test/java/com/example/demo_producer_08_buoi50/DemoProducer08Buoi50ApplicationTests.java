package com.example.demo_producer_08_buoi50;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProducer08Buoi50ApplicationTests {

	@Test
	void contextLoads() {
	}

}
