package com.example.product08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Product08Application {

	public static void main(String[] args) {
		SpringApplication.run(Product08Application.class, args);
	}

}
