package com.example.demo_buoi34;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBuoi34ApplicationTests {

	@Test
	void contextLoads() {
	}

}
