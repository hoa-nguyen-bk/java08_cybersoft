package com.cybersoft.uniclub08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uniclub08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
