package com.cybersoft.uniclub08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Uniclub08Application {

	public static void main(String[] args) {
		SpringApplication.run(Uniclub08Application.class, args);
	}

}
