package com.cybersoft.uniclub08.services;

public interface AuthenticationServices {
    String authenticate(String username, String password);
}
