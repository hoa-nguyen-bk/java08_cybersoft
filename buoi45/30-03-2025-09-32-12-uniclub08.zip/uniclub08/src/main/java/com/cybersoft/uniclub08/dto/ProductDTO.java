package com.cybersoft.uniclub08.dto;

import lombok.Data;

@Data
public class ProductDTO {

    private String urlImage;
    private String name;
    private double price;

}
